/* tslint:disable */
require("./SinglePartPageWebPart.module.css");
const styles = {
  singlePartPage: 'singlePartPage_be8695a6',
  container: 'container_be8695a6',
  row: 'row_be8695a6',
  column: 'column_be8695a6',
  'ms-Grid': 'ms-Grid_be8695a6',
  title: 'title_be8695a6',
  subTitle: 'subTitle_be8695a6',
  description: 'description_be8695a6',
  button: 'button_be8695a6',
  label: 'label_be8695a6',
};

export default styles;
/* tslint:enable */