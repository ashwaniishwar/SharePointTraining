declare interface ISinglePartPageWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SinglePartPageWebPartStrings' {
  const strings: ISinglePartPageWebPartStrings;
  export = strings;
}
