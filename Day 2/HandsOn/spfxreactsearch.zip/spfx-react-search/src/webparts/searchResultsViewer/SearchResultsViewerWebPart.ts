import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { IWebPartContext } from '@microsoft/sp-webpart-base';

import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';

import * as strings from 'SearchResultsViewerWebPartStrings';
import SearchResultsViewer from './components/SearchResultsViewer';
import { ISearchResultsViewerProps } from './components/ISearchResultsViewerProps';

export interface ISearchResultsViewerWebPartProps {
  description: string;
  spContext: IWebPartContext
}

export default class SearchResultsViewerWebPart extends BaseClientSideWebPart<ISearchResultsViewerWebPartProps> {

  public render(): void {
    const element: React.ReactElement<ISearchResultsViewerProps > = React.createElement(
      SearchResultsViewer,
      {
        description: this.properties.description,
        spContext: this.context
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
