import * as React from 'react';
import styles from './SearchResultsViewer.module.scss';
import { ISearchResultsViewerProps } from './ISearchResultsViewerProps';
import { ISearchResultsViewerState } from './ISearchResultsViewerState';

import SearchService from "../services/SearchService";

// Import Textfield component 
import { TextField } from 'office-ui-fabric-react/lib/TextField';

// Import Button component  
import { IButtonProps, DefaultButton } from 'office-ui-fabric-react/lib/Button';

// Import List component
import { FocusZone, FocusZoneDirection } from 'office-ui-fabric-react/lib/FocusZone';
import { List } from 'office-ui-fabric-react/lib/List';

// Import Link component
import { Link } from 'office-ui-fabric-react/lib/Link';


import { escape } from '@microsoft/sp-lodash-subset';
import { ISPSearchResult } from './ISPSearchResult';

export default class SearchResultsViewer extends React.Component<ISearchResultsViewerProps, ISearchResultsViewerState> {
  private _searchService: SearchService;

  constructor(props: ISearchResultsViewerProps, state: ISearchResultsViewerState) {
    super(props);

    // Initialize the search service
    this._searchService = new SearchService(this.props.spContext);

    this.state = {
      status: "Ready",
      searchText: "",
      items: []
    }

    this._searchClicked = this._searchClicked.bind(this); 
  }

  public render(): React.ReactElement<ISearchResultsViewerProps> {

    return (
      <div className={ styles.searchResultsViewer }>
        <div className={ styles.container }>
          <div className={ styles.row }>
            <div className={ styles.column }>
              <span className={ styles.title }>Welcome to SharePoint!</span>
              <p className={ styles.subTitle }>Retrieve search results using REST API</p>

              <TextField   
                  required={true}   
                  name="txtSearchText"   
                  placeholder="Search..."  
                  value={this.state.searchText}  
                  onChanged={e => this.setState({ searchText: e })}  
              />  

              <DefaultButton  
                  data-automation-id="search"  
                  target="_blank"  
                  title="Search"  
                  onClick={this._searchClicked}  
                  >  
                  Search  
              </DefaultButton>

              <FocusZone direction={FocusZoneDirection.vertical}>
                <div className="ms-ListGhostingExample-container" data-is-scrollable={true}>
                  <List items={this.state.items} onRenderCell={this._onRenderCell} />
                </div>
              </FocusZone>

            </div>
          </div>
        </div>
      </div>
    );
  }

  private _searchClicked(): void {
      this._searchService.getSearchResults(this.state.searchText)
        .then((searchResp: ISPSearchResult[]): void => {
          this.setState({
            status: 'Creating item...',
            items: searchResp
          });
      });
  }

  private _onRenderCell(item: ISPSearchResult, index: number, isScrolling: boolean): JSX.Element {
    return (
      <div className="ms-ListGhostingExample-itemCell" data-is-focusable={true}>
        <div className="ms-ListGhostingExample-itemContent">
          <div className="ms-ListGhostingExample-itemName">
            <Link href={item.Url}>{item.Title}</Link>          
          </div>
          <div className="ms-ListGhostingExample-itemName">{item.Description}</div>
          <p></p>
          {/* <div className="ms-ListGhostingExample-itemIndex">{`Item ${index}`}</div> */}
        </div>
      </div>
    );
  }
}
