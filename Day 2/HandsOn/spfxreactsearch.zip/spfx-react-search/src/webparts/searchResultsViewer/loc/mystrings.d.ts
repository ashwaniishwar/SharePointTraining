declare interface ISearchResultsViewerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SearchResultsViewerWebPartStrings' {
  const strings: ISearchResultsViewerWebPartStrings;
  export = strings;
}
