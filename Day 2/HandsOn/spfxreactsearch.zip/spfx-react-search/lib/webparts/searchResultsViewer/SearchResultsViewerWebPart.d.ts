import { Version } from '@microsoft/sp-core-library';
import { IWebPartContext } from '@microsoft/sp-webpart-base';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface ISearchResultsViewerWebPartProps {
    description: string;
    spContext: IWebPartContext;
}
export default class SearchResultsViewerWebPart extends BaseClientSideWebPart<ISearchResultsViewerWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
