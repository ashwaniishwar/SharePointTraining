import { IWebPartContext } from '@microsoft/sp-webpart-base';
export interface ISearchResultsViewerProps {
    description: string;
    spContext: IWebPartContext;
}
