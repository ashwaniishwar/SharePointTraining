export interface ISPSearchResult {
    Title: string;
    Description: string;
    Url: string;
}
