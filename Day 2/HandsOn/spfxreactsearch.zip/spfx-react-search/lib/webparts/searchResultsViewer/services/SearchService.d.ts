import { IWebPartContext } from '@microsoft/sp-webpart-base';
import { ISPSearchResult } from '../components/ISPSearchResult';
export default class SearchService {
    private _context;
    constructor(_context: IWebPartContext);
    getSearchResults(query: string): Promise<ISPSearchResult[]>;
    /**
    * Retrieve the results from the search API
    *
    * @param url
    */
    private _getSearchData(url);
    /**
     * Set the current set of search results
     *
     * @param crntResults
     * @param fields
     */
    private _setSearchResults(crntResults, fields);
    /**
     * Check if the value is null or undefined
     *
     * @param value
     */
    private _isNull(value);
}
