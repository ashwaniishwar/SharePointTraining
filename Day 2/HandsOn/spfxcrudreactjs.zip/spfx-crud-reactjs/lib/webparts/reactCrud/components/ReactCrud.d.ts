/// <reference types="react" />
import * as React from 'react';
import { IReactCrudProps } from './IReactCrudProps';
import { IReactCrudState } from './IReactCrudState';
export default class ReactCrud extends React.Component<IReactCrudProps, IReactCrudState> {
    constructor(props: IReactCrudProps, state: IReactCrudState);
    render(): React.ReactElement<IReactCrudProps>;
    private getLatestItemId();
    private createItem();
    private readItem();
    private updateItem();
    private deleteItem();
}
