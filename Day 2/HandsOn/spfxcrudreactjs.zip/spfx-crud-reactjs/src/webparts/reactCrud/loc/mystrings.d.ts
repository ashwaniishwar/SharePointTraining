declare interface IReactCrudWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ListNameFieldLabel: string;
}

declare module 'ReactCrudWebPartStrings' {
  const strings: IReactCrudWebPartStrings;
  export = strings;
}
